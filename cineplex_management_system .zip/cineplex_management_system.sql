-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 05, 2021 at 06:39 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cineplex_management_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `E_id` int(11) NOT NULL,
  `E_name` varchar(25) DEFAULT 'No name',
  `E_email` varchar(20) DEFAULT NULL,
  `E_salary` int(11) DEFAULT NULL CHECK (`E_salary` > 0),
  `E_address` varchar(35) NOT NULL,
  `E_age` int(11) DEFAULT NULL CHECK (`E_age` > 16),
  `E_phone` int(11) DEFAULT NULL,
  `bonus_salary` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`E_id`, `E_name`, `E_email`, `E_salary`, `E_address`, `E_age`, `E_phone`, `bonus_salary`) VALUES
(101, 'Asif', 'asif898@gmail.com', 4500, 'Mirpur-2,Dhaka', 17, 928238121, 2250),
(102, 'Rakib', 'rakib3452@gmail.com', 4500, 'Nilkhelt,Dhaka', 18, 92873615, 2250),
(103, 'Sakib', 'sakib66@yahoo.com', 4200, 'Panthapoth,Dhaka', 20, 93275634, 2100),
(104, 'Jisan', 'jissan33@gmail.com', 4000, 'Gulsan,Dhaka', 22, 391231024, 2000),
(105, 'Rakin', 'rakin27@gmail.com', 5000, 'Bananni,Dhaka', 17, 391827652, 2500),
(106, 'Turjo', 'turjo44@gmail.com', 4800, 'Kuratoli,Dhka', 18, 51234520, 2400),
(107, 'Rouf', 'rouf78@gmail.com', 3500, 'Mirpur,Dhaka', 24, 412783102, 1750),
(108, 'Tutol', 'tutol44@gmail.com', 4800, 'Zatrabari,Dhaka', 20, 21234192, 2400),
(109, 'Shuvro', 'shu44@gmail.com', 4700, 'Bananni,Dhaka', 20, 192031234, 2350),
(110, 'Rifat', 'rifat99@gmail.com', 5000, 'Mirpur,Dhaka', 22, 91837212, 2500);

--
-- Triggers `employee`
--
DELIMITER $$
CREATE TRIGGER `bonus_salary` BEFORE INSERT ON `employee` FOR EACH ROW BEGIN

SET NEW.bonus_salary = NEW.E_salary/2;

END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `home_mirpur`
-- (See below for the actual view)
--
CREATE TABLE `home_mirpur` (
`M_name` varchar(25)
,`M_Address` varchar(35)
,`M_phone` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE `manager` (
  `M_id` int(11) NOT NULL,
  `M_name` varchar(25) NOT NULL,
  `M_address` varchar(35) NOT NULL,
  `M_phone` int(11) DEFAULT NULL,
  `M_email` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`M_id`, `M_name`, `M_address`, `M_phone`, `M_email`) VALUES
(1, 'Rahman \r\nHasan', 'Mirpur-10,Dhaka', 117262589, 'rhasan@gmail.com'),
(2, 'Kabir \r\nHasan', 'Mirpur-2,Dhaka', 113456589, 'khasan@gmail.com'),
(3, 'Anik \r\nPaul', 'Nikunja-2,khilkhet', 517002389, 'anikp@gmail.com'),
(4, 'Ashik \r\nRahman', 'Mirpur-1,Dhaka', 419354729, 'ashik695@gmail.com'),
(5, 'Shawon\r\nZaman', 'Nikunja-2,khilkhet', 616219424, 'szaman@gmail.com'),
(6, 'Chisty \r\nNomanuzzaman', 'kuratoli,Dhaka', 280981723, 'chisty767@gmail.com'),
(7, 'Emtiaz \r\nAnik', 'Kuratoli,Dhaka', 29176589, 'anik876@yahoo.com'),
(8, 'Ahmed \r\nAwsaf', 'Mirpur-10,Dhaka', 98276523, 'awsaf897@gmail.com'),
(9, 'Ashesh \r\nTalukdar', 'Rampura,Dhaka', 93672938, 'ashesh676@gmail.com'),
(10, 'Murad \r\nElahi', 'Kuratoli,Dhaka', 39721538, 'murad667@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `shows`
--

CREATE TABLE `shows` (
  `S_id` int(11) NOT NULL,
  `S_name` varchar(15) DEFAULT 'No name',
  `Start_time` varchar(6) NOT NULL,
  `End_time` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `shows`
--

INSERT INTO `shows` (`S_id`, `S_name`, `Start_time`, `End_time`) VALUES
(1, 'Movie 1', '9 am', '10 am'),
(2, 'Movie 2', '10 am', '11 am'),
(3, 'Movie 3', '11 am', '12 pm'),
(4, 'Movie 4', '12 pm', '1 pm'),
(5, 'Movie 5', '1 pm', '2 pm'),
(6, 'Movie 1', '3 pm', '4 pm'),
(7, 'Movie 3', '4 pm', '5 pm'),
(8, 'Movie 4', '5 pm', '6 pm'),
(9, 'Movie 2', '6 pm', '7 pm'),
(10, 'Movie 5', '7 pm', '8 pm');

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `T_id` int(11) NOT NULL,
  `T_name` varchar(15) DEFAULT 'No name',
  `T_price` int(11) DEFAULT NULL CHECK (`T_price` > 300)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`T_id`, `T_name`, `T_price`) VALUES
(1, 'General', 320),
(2, 'VIP', 500),
(3, 'PREMIUM', 400),
(4, 'General', 320),
(5, 'PREMIUM', 400),
(6, 'General', 320),
(7, 'VIP', 500),
(8, 'PREMIUM', 400),
(9, 'PREMIUM', 400),
(10, 'VIP', 500);

-- --------------------------------------------------------

--
-- Table structure for table `ticket_show`
--

CREATE TABLE `ticket_show` (
  `T_id` int(11) NOT NULL,
  `T_name` varchar(15) DEFAULT 'No name',
  `T_price` int(11) DEFAULT NULL CHECK (`T_price` > 300),
  `S_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ticket_show`
--

INSERT INTO `ticket_show` (`T_id`, `T_name`, `T_price`, `S_id`) VALUES
(1, 'General', 320, 1),
(2, 'VIP', 500, 2),
(3, 'PREMIUM', 400, 3),
(4, 'General', 320, 4),
(5, 'PREMIUM', 400, 5),
(6, 'General', 320, 6),
(7, 'VIP', 500, 7),
(8, 'PREMIUM', 400, 8),
(9, 'PREMIUM', 400, 9),
(10, 'VIP', 500, 10);

-- --------------------------------------------------------

--
-- Structure for view `home_mirpur`
--
DROP TABLE IF EXISTS `home_mirpur`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `home_mirpur`  AS  select `manager`.`M_name` AS `M_name`,`manager`.`M_address` AS `M_Address`,`manager`.`M_phone` AS `M_phone` from `manager` where `manager`.`M_address` like 'Mirpur%' ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`E_id`),
  ADD UNIQUE KEY `E_email` (`E_email`),
  ADD UNIQUE KEY `E_phone` (`E_phone`);

--
-- Indexes for table `manager`
--
ALTER TABLE `manager`
  ADD PRIMARY KEY (`M_id`),
  ADD UNIQUE KEY `M_phone` (`M_phone`),
  ADD UNIQUE KEY `M_email` (`M_email`);

--
-- Indexes for table `shows`
--
ALTER TABLE `shows`
  ADD PRIMARY KEY (`S_id`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`T_id`);

--
-- Indexes for table `ticket_show`
--
ALTER TABLE `ticket_show`
  ADD PRIMARY KEY (`T_id`),
  ADD KEY `fk_S_id` (`S_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ticket_show`
--
ALTER TABLE `ticket_show`
  ADD CONSTRAINT `fk_S_id` FOREIGN KEY (`S_id`) REFERENCES `shows` (`S_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
